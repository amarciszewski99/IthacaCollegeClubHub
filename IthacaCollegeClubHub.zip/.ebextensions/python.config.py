option_settings:
    "aws:elasticbeanstalk:container:python":
    WSGIPath: application:application